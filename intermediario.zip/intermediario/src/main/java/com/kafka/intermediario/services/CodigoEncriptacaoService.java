package com.kafka.intermediario.services;

import java.util.List;

public interface CodigoEncriptacaoService<T, K> {

    public List<T> codigos();

}
