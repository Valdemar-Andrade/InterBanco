package com.kafka.intermediario.utils;

import java.util.UUID;

public class UUIDGenerator {

    public static UUID gerarUUID(){
        return UUID.randomUUID();
    }

}
