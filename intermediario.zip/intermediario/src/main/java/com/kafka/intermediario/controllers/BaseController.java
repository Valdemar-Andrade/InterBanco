package com.kafka.intermediario.controllers;

import com.kafka.intermediario.utils.ResponseControllerUtils;

public class BaseController extends ResponseControllerUtils {

}
