package com.kafka.intermediario.utils;

import com.kafka.intermediario.dto.SaldoDTO;
import com.kafka.intermediario.dto.TransacaoDTO;

import java.util.ArrayList;

public class ArrayTransacaoManipulator {

    //public static ArrayList<TransacaoDTO> arrayTransacoesRecebidas;

    public static ArrayList<TransacaoDTO> arrayTransacoes = new ArrayList<>();

    public static ArrayList<SaldoDTO> arrayTransacoesConsulta = new ArrayList<>();

}
