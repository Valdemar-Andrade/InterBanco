package com.kafka.intermediario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntermediarioApplicationTests {

    @Test
    void contextLoads() {
    }

}
