package com.banco.banco1.services;

import java.util.List;

public interface CodigoEncriptacaoService<T, K> {

    public List<T> codigos();

}
