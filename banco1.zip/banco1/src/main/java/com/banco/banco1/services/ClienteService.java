package com.banco.banco1.services;

import java.util.List;

public interface ClienteService<T, K>{

    public List<T> clientes();
}
