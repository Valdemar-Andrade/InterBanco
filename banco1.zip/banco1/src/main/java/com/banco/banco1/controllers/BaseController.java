package com.banco.banco1.controllers;

import com.banco.banco1.utils.ResponseControllerUtils;

public class BaseController extends ResponseControllerUtils {

}
