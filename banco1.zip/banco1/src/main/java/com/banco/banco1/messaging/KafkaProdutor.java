package com.banco.banco1.messaging;

public class KafkaProdutor {



}
