package com.banco.banco1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Banco1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
