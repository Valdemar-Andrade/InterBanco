package com.banco.banco2.controllers;

import com.banco.banco2.utils.ResponseControllerUtils;

public class BaseController extends ResponseControllerUtils {

}
