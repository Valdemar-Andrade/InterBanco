package com.banco.banco2.services;

import java.util.List;

public interface CodigoEncriptacaoService<T, K> {

    public List<T> codigos();

}
