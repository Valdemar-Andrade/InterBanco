package com.banco.banco2.utils;

import java.util.UUID;

public class UUIDGenerator {

    public static UUID gerarUUID(){
        return UUID.randomUUID();
    }

}
