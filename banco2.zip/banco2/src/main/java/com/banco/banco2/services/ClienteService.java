package com.banco.banco2.services;

import java.util.List;

public interface ClienteService<T, K>{

    public List<T> clientes();
}
