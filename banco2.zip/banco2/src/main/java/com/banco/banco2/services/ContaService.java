package com.banco.banco2.services;

import java.util.List;

public interface ContaService<T, K>{

    public List<T> contas();
}
