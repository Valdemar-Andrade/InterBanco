package com.banco.banco2.messaging;

public class KafkaProdutor {



}
