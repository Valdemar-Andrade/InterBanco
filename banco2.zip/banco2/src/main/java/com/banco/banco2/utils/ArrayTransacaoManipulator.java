package com.banco.banco2.utils;

import com.banco.banco2.dto.TransacaoDTO;

import java.util.ArrayList;

public class ArrayTransacaoManipulator {

    //public static ArrayList<TransacaoDTO> arrayTransacoesRecebidas;

    public static ArrayList<TransacaoDTO> arrayTransacoes = new ArrayList<>();

}
