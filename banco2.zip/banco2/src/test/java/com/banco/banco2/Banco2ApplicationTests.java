package com.banco.banco2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Banco2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
